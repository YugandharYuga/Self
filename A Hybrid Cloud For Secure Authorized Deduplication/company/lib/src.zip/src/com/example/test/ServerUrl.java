package com.example.test;

public class ServerUrl {
	//http://192.168.0.105:8888/wemeet/Register
	//http://192.168.0.104:8888/wemeet/Login
	//http://192.168.0.104:8888/wemeet/MeetRequest
public static String getServerUrl(){
	return "http://wemeetsmartapp.s155.eatj.com/wemeet";
}
}
